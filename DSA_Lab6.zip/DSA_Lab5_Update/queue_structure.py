from linked_list import LinkedList


class Queue:
    def __init__(self):
        self._items = LinkedList()

    def enqueue(self, value):
        self._items.insert_at_end(value)

    def dequeue(self):
        return self._items.remove_beginning()

    def is_empty(self):
        return self._items.is_empty()

    def to_list(self):
        return self._items.to_list()
