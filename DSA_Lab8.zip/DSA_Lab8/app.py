import re

from flask import Flask, render_template, request

from binary_tree import BinaryTree
from linked_list import LinkedList
from queue_structure import Queue
from sorting_algo import parse_sort_values, sort_numbers
from stack import Stack

app = Flask(__name__)

INFIX_TOKEN_PATTERN = re.compile(
    r'\s*(\d+(?:\.\d*)?|\.\d+|[A-Za-z_][A-Za-z0-9_]*|[()+\-*/^])'
)


def infix_to_postfix(expression):
    tokens = []
    position = 0
    while position < len(expression):
        match = INFIX_TOKEN_PATTERN.match(expression, position)
        if not match:
            if expression[position:].strip():
                raise ValueError(f"Invalid character: '{expression[position]}'.")
            break
        tokens.append(match.group(1))
        position = match.end()

    if not tokens:
        raise ValueError('Enter an expression to convert.')

    precedence = {'+': 1, '-': 1, '*': 2, '/': 2, 'u+': 3, 'u-': 3, '^': 4}
    right_associative = {'^', 'u+', 'u-'}
    operators = Stack()
    output = []
    expecting_operand = True

    for token in tokens:
        if re.fullmatch(r'\d+(?:\.\d*)?|\.\d+|[A-Za-z_][A-Za-z0-9_]*', token):
            if not expecting_operand:
                raise ValueError('Add an operator between operands.')
            output.append(token)
            expecting_operand = False
        elif token == '(':
            if not expecting_operand:
                raise ValueError("Add an operator before '('.")
            operators.push(token)
            expecting_operand = True
        elif token == ')':
            if expecting_operand:
                raise ValueError("Unexpected ')' or empty parentheses.")
            while not operators.is_empty() and operators.peek() != '(':
                operator = operators.pop()
                output.append({'u+': 'POS', 'u-': 'NEG'}.get(operator, operator))
            if operators.is_empty():
                raise ValueError("Unmatched ')'.")
            operators.pop()
            expecting_operand = False
        else:
            if expecting_operand:
                if token in ('+', '-'):
                    operators.push('u' + token)
                    continue
                raise ValueError(f"Unexpected operator '{token}'.")

            while not operators.is_empty() and operators.peek() != '(':
                top = operators.peek()
                if (precedence[top] > precedence[token]
                        or (precedence[top] == precedence[token]
                            and token not in right_associative)):
                    operator = operators.pop()
                    output.append({'u+': 'POS', 'u-': 'NEG'}.get(operator, operator))
                else:
                    break
            operators.push(token)
            expecting_operand = True

    if expecting_operand:
        raise ValueError('Expression cannot end with an operator.')

    while not operators.is_empty():
        operator = operators.pop()
        if operator == '(':
            raise ValueError("Unmatched '('.")
        output.append({'u+': 'POS', 'u-': 'NEG'}.get(operator, operator))

    return ' '.join(output)


def postfix_to_infix(expression):
    stripped_expression = expression.strip()
    if any(character.isspace() for character in stripped_expression):
        tokens = stripped_expression.split()
    else:
        tokens = list(stripped_expression)
    if not tokens:
        raise ValueError('Enter a postfix expression to convert.')

    operands = Stack()
    binary_operators = {'+', '-', '*', '/', '^'}
    for token in tokens:
        if token in binary_operators:
            if len(operands.to_list()) < 2:
                raise ValueError(f"Not enough operands for '{token}'.")
            right = operands.pop()
            left = operands.pop()
            operands.push(f'({left} {token} {right})')
        elif token in ('NEG', 'POS'):
            if operands.is_empty():
                raise ValueError(f"Not enough operands for '{token}'.")
            operand = operands.pop()
            sign = '-' if token == 'NEG' else '+'
            operands.push(f'({sign}{operand})')
        elif re.fullmatch(r'\d+(?:\.\d*)?|\.\d+|[A-Za-z_][A-Za-z0-9_]*', token):
            operands.push(token)
        else:
            raise ValueError(f"Invalid token: '{token}'.")

    if len(operands.to_list()) != 1:
        raise ValueError('The postfix expression has too many operands or is missing an operator.')

    return operands.peek()


def parse_linked_list_values(raw_values):
    if not raw_values:
        return []
    values = []
    for item in raw_values.split(','):
        value = item.strip()
        if value:
            values.append(value)
    return values


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/profile')
def profile():
    return render_template('profile.html')


@app.route('/works', methods=['GET', 'POST'])
def works():
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
        return render_template('touppercase.html', result=result)
    return render_template('works.html')


@app.route('/works/uppercase', methods=['GET', 'POST'])
def uppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)


@app.route('/works/sorting', methods=['GET', 'POST'])
def sorting():
    numbers_input = ''
    algorithm = 'bubble_sort'
    result = None
    steps = []
    steps_truncated = False
    error = None

    if request.method == 'POST':
        numbers_input = request.form.get('numbers', '')
        algorithm = request.form.get('algorithm', 'bubble_sort')

        try:
            values = parse_sort_values(numbers_input)
            if not values:
                error = 'Enter at least one number to sort.'
            else:
                result, steps, steps_truncated = sort_numbers(values, algorithm)
        except ValueError as exc:
            error = str(exc)

    return render_template(
        'sorting.html',
        numbers_input=numbers_input,
        algorithm=algorithm,
        result=result,
        steps=steps,
        steps_truncated=steps_truncated,
        error=error,
    )


@app.route('/works/binary-tree', methods=['GET', 'POST'])
def binary_tree():
    raw_values = ''
    tree = None
    preorder = None
    inorder = None
    postorder = None
    error = None

    if request.method == 'POST':
        raw_values = request.form.get('values', '')
        values = [value.strip() for value in raw_values.split(',') if value.strip()]
        if not values:
            error = 'Enter at least one node value.'
        else:
            tree = BinaryTree(values[0])
            nodes = [tree.root]
            for index, value in enumerate(values[1:], start=1):
                parent = nodes[(index - 1) // 2]
                if index % 2:
                    tree.insert_left(parent, value)
                    nodes.append(parent.left)
                else:
                    tree.insert_right(parent, value)
                    nodes.append(parent.right)

            preorder = tree.preorder_traversal(tree.root, '').strip()
            inorder = tree.inorder_traversal(tree.root, '').strip()
            postorder = tree.postorder_traversal(tree.root, '').strip()

    return render_template(
        'binary_tree.html',
        raw_values=raw_values,
        tree=tree,
        preorder=preorder,
        inorder=inorder,
        postorder=postorder,
        error=error,
    )


@app.route('/works/expression-converter', methods=['GET', 'POST'])
def expression_converter():
    infix_expression = ''
    postfix_expression = ''
    conversion = None
    result = None
    error = None

    if request.method == 'POST':
        conversion = request.form.get('conversion', '')
        infix_expression = request.form.get('infix_expression', '')
        postfix_expression = request.form.get('postfix_expression', '')

        try:
            if conversion == 'infix_to_postfix':
                result = infix_to_postfix(infix_expression)
            elif conversion == 'postfix_to_infix':
                result = postfix_to_infix(postfix_expression)
            else:
                error = 'Choose a conversion direction.'
        except ValueError as exc:
            error = str(exc)

    return render_template(
        'expression_converter.html',
        infix_expression=infix_expression,
        postfix_expression=postfix_expression,
        conversion=conversion,
        result=result,
        error=error,
    )


@app.route('/works/linked-list', methods=['GET', 'POST'])
def linked_list():
    linked_values = []
    operation = 'insert_end'
    message = None
    show_list = False

    if request.method == 'POST':
        show_list = True
        raw_values = request.form.get('values', '')
        linked_values = parse_linked_list_values(raw_values)
        linked_list_data = LinkedList()
        for value in linked_values:
            linked_list_data.insert_at_end(value)
        operation = request.form.get('operation', 'insert_end')
        new_value = request.form.get('new_value', '').strip()

        if operation in ('insert_beginning', 'prepend') and new_value:
            linked_list_data.insert_at_beginning(new_value)
        elif operation in ('insert_end', 'append') and new_value:
            linked_list_data.insert_at_end(new_value)
        elif operation == 'remove_beginning':
            if not linked_list_data.is_empty():
                linked_list_data.remove_beginning()
            else:
                message = 'The list is empty; there is no node to remove.'
        elif operation == 'remove_end':
            if not linked_list_data.is_empty():
                linked_list_data.remove_at_end()
            else:
                message = 'The list is empty; there is no node to remove.'
        elif operation == 'insert':
            if not new_value:
                message = 'Enter a value to insert.'
            else:
                try:
                    index = int(request.form.get('index', '0').strip())
                except ValueError:
                    message = 'Enter a whole-number position.'
                else:
                    if 0 <= index <= linked_list_data.length:
                        linked_list_data.insert_at(index, new_value)
                    else:
                        message = f'Insert position must be between 0 and {linked_list_data.length}.'
        elif operation == 'remove_position':
            try:
                index = int(request.form.get('index', '0').strip())
            except ValueError:
                message = 'Enter a whole-number position.'
            else:
                if 0 <= index < linked_list_data.length:
                    linked_list_data.remove_at_index(index)
                else:
                    message = f'Remove position must be between 0 and {linked_list_data.length - 1}.'
        elif operation not in ('insert_beginning', 'prepend', 'insert_end', 'append'):
            message = 'Choose a valid linked-list operation.'
        elif not new_value:
            message = 'Enter a value to insert.'

        linked_values = linked_list_data.to_list()

    return render_template(
        'linked_list.html',
        values=linked_values,
        show_list=show_list,
        operation=operation,
        message=message,
    )


@app.route('/works/queue', methods=['GET', 'POST'])
def queue():
    queue_data = Queue()
    for value in request.form.getlist('values'):
        queue_data.enqueue(value)

    message = None
    show_queue = request.method == 'POST'

    if request.method == 'POST':
        operation = request.form.get('operation', '')
        new_value = request.form.get('new_value', '').strip()

        if operation == 'enqueue':
            if new_value:
                queue_data.enqueue(new_value)
                message = f'Enqueued {new_value}.'
            else:
                message = 'Enter a value to enqueue.'
        elif operation == 'dequeue':
            removed_value = queue_data.dequeue()
            if removed_value is None:
                message = 'The queue is empty; there is no value to dequeue.'
            else:
                message = f'Dequeued {removed_value}.'
        else:
            message = 'Choose a valid queue operation.'

    return render_template(
        'queue.html',
        values=queue_data.to_list(),
        show_queue=show_queue,
        message=message,
    )


@app.route('/works/area/circle', methods=['GET', 'POST'])
def acircle():
    result = None
    if request.method == 'POST':
        radius = request.form.get('radius', '')
        result = int(radius) * 3.14 * int(radius)
    return render_template('circle.html', result=result)


@app.route('/works/area/triangle', methods=['GET', 'POST'])
def atriangle():
    result = None
    if request.method == 'POST':
        base = request.form.get('base', '')
        height = request.form.get('height', '')
        if base and height:
            result = float(base) * float(height) / 2
    return render_template('triangle.html', result=result)


# @app.route('/areaOfcirle', methods=['GET', 'POST'])
# def areaOfcirle():
#     result = None
#     name=request.get('name','')
#     print(name)
#     if request.method == 'POST':
#         input_string = request.form.get('inputradius', '')
#         result = int(input_string) * int(input_string) * 3.14
#     return render_template('areaCircle.html', result=result)


@app.route('/contact')
def contact():
    return render_template('contact.html')


if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5000, debug=False, use_reloader=False)
