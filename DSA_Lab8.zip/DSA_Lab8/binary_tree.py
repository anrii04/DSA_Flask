class Node:
    """A node in a binary tree."""

    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right


class BinaryTree:
    """A binary tree with left/right insertion and depth-first traversals."""

    def __init__(self, root_value=None):
        self.root = Node(root_value) if root_value is not None else None

    def insert_left(self, current_node, value):
        """Insert a value as the left child, placing it above an existing child."""
        if current_node.left is None:
            current_node.left = Node(value)
        else:
            current_node.left = Node(value, left=current_node.left)

    def insert_right(self, current_node, value):
        """Insert a value as the right child, placing it above an existing child."""
        if current_node.right is None:
            current_node.right = Node(value)
        else:
            current_node.right = Node(value, right=current_node.right)

    def preorder_traversal(self, start, traversal=''):
        """Return values in root-left-right order."""
        if start:
            traversal += str(start.value) + ' '
            traversal = self.preorder_traversal(start.left, traversal)
            traversal = self.preorder_traversal(start.right, traversal)
        return traversal

    def inorder_traversal(self, start, traversal=''):
        """Return values in left-root-right order."""
        if start:
            traversal = self.inorder_traversal(start.left, traversal)
            traversal += str(start.value) + ' '
            traversal = self.inorder_traversal(start.right, traversal)
        return traversal

    def postorder_traversal(self, start, traversal=''):
        """Return values in left-right-root order."""
        if start:
            traversal = self.postorder_traversal(start.left, traversal)
            traversal = self.postorder_traversal(start.right, traversal)
            traversal += str(start.value) + ' '
        return traversal
