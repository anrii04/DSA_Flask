import math


MAX_SORT_STEPS = 250


def parse_sort_values(raw_values):
    if not raw_values or not raw_values.strip():
        return []
    values = []
    for item in raw_values.split(','):
        cleaned = item.strip()
        if not cleaned:
            continue
        try:
            number = float(cleaned)
        except ValueError as exc:
            raise ValueError(f"Invalid number: '{cleaned}'. Use numbers separated by commas.") from exc
        if not math.isfinite(number):
            raise ValueError(f"Invalid number: '{cleaned}'. Enter finite numbers only.")
        values.append(int(number) if number.is_integer() else number)
    return values


def _record_sort_step(trace, description, values, active_indices=()):
    if len(trace['steps']) < MAX_SORT_STEPS:
        trace['steps'].append({
            'description': description,
            'values': values[:],
            'active_indices': list(active_indices),
        })
    else:
        trace['truncated'] = True


def _bubble_sort(values, trace):
    sorted_values = values[:]
    n = len(sorted_values)
    for i in range(n):
        for j in range(0, n - i - 1):
            left_value = sorted_values[j]
            right_value = sorted_values[j + 1]
            _record_sort_step(
                trace,
                f"Compare {left_value} and {right_value}.",
                sorted_values,
                (j, j + 1),
            )
            if left_value > right_value:
                sorted_values[j], sorted_values[j + 1] = sorted_values[j + 1], sorted_values[j]
                _record_sort_step(
                    trace,
                    f"Swap them because {left_value} is greater than {right_value}.",
                    sorted_values,
                    (j, j + 1),
                )
    return sorted_values


def _selection_sort(values, trace):
    sorted_values = values[:]
    n = len(sorted_values)
    for i in range(n):
        minimum_index = i
        for j in range(i + 1, n):
            _record_sort_step(
                trace,
                f"Compare {sorted_values[j]} with the current minimum {sorted_values[minimum_index]}.",
                sorted_values,
                (minimum_index, j),
            )
            if sorted_values[j] < sorted_values[minimum_index]:
                minimum_index = j
                _record_sort_step(
                    trace,
                    f"{sorted_values[minimum_index]} is the new minimum for this pass.",
                    sorted_values,
                    (i, minimum_index),
                )
        sorted_values[i], sorted_values[minimum_index] = sorted_values[minimum_index], sorted_values[i]
        _record_sort_step(
            trace,
            f"Place the pass's minimum ({sorted_values[i]}) at position {i}.",
            sorted_values,
            (i, minimum_index),
        )
    return sorted_values


def _insertion_sort(values, trace):
    sorted_values = values[:]
    for i in range(1, len(sorted_values)):
        key = sorted_values[i]
        j = i - 1
        _record_sort_step(
            trace,
            f"Take {key} as the next value to insert into the sorted left side.",
            sorted_values,
            (i,),
        )
        while j >= 0 and sorted_values[j] > key:
            _record_sort_step(
                trace,
                f"Shift {sorted_values[j]} one position right because it is greater than {key}.",
                sorted_values,
                (j, j + 1),
            )
            sorted_values[j + 1] = sorted_values[j]
            j -= 1
        sorted_values[j + 1] = key
        _record_sort_step(
            trace,
            f"Insert {key} at position {j + 1}.",
            sorted_values,
            (j + 1,),
        )
    return sorted_values


def _merge_sort(values, trace):
    if len(values) <= 1:
        return values[:]

    midpoint = len(values) // 2
    _record_sort_step(
        trace,
        f"Split {values} into {values[:midpoint]} and {values[midpoint:]}.",
        values,
    )
    left = _merge_sort(values[:midpoint], trace)
    right = _merge_sort(values[midpoint:], trace)
    merged = []
    left_index = 0
    right_index = 0

    while left_index < len(left) and right_index < len(right):
        if left[left_index] <= right[right_index]:
            merged.append(left[left_index])
            left_index += 1
        else:
            merged.append(right[right_index])
            right_index += 1
        _record_sort_step(
            trace,
            f"Merge the smaller next value; current merged part: {merged}.",
            merged,
        )

    merged.extend(left[left_index:])
    merged.extend(right[right_index:])
    _record_sort_step(trace, f"Finish merging this part: {merged}.", merged)
    return merged


def _quick_sort(values, trace):
    if len(values) <= 1:
        return values[:]

    pivot = values[len(values) // 2]
    left = [value for value in values if value < pivot]
    middle = [value for value in values if value == pivot]
    right = [value for value in values if value > pivot]
    _record_sort_step(
        trace,
        f"Choose {pivot} as the pivot and partition into {left} (less), {middle} (equal), and {right} (greater).",
        left + middle + right,
    )
    return _quick_sort(left, trace) + middle + _quick_sort(right, trace)


SORTERS = {
    'bubble_sort': _bubble_sort,
    'selection_sort': _selection_sort,
    'insertion_sort': _insertion_sort,
    'merge_sort': _merge_sort,
    'quick_sort': _quick_sort,
}


def sort_numbers(values, algorithm):
    sorter = SORTERS.get(algorithm)
    if sorter is None:
        raise ValueError('Choose a valid sorting algorithm.')

    trace = {'steps': [], 'truncated': False}
    result = sorter(values, trace)
    _record_sort_step(trace, f"Sorting complete. Final order: {result}.", result)
    return result, trace['steps'], trace['truncated']
